import os
import uuid
import torch
from fastapi import FastAPI, File, UploadFile
from mmcls.apis import init_model, inference_model
from mmcls.datasets.pipelines import Compose, Resize, LoadImageFromFile, RGBToGrayscale, CenterCrop, Normalize, ImageToTensor, Collect
from tools.visualizations.vis_cam_ import *
from mmcv import Config
app = FastAPI()

use_cuda = torch.cuda.is_available()
device = "cuda" if use_cuda else "cpu"
config_file = r'C:\Users\user\Documents\GitHub\mmclassification\configs\resnet\resnet50_8xb32_in1k copy.py'
checkpoint_file = r'C:\Users\user\Documents\GitHub\mmclassification\work_dir\resnet50_None\latest.pth'
model = init_model(config_file, checkpoint_file, device=device)
model.CLASSES = ['Normal', 'Tuberculosis']
cfg = Config.fromfile(config_file)
	
@app.post("/predict")
async def predict_image(file: UploadFile = File(...)):
	upload_path = r'./uploaded_img'
	grad_path = r'C:\Users\user\Documents\GitHub\mmclassification\backend_server\grad_img'
	if not os.path.exists(upload_path):
		os.makedirs(upload_path)
	
	contents = await file.read()
	file_ext = os.path.splitext(file.filename)[-1]
	unique_filename = f"{uuid.uuid4().hex}.png"
	image_filepath = os.path.join(upload_path, unique_filename)

	with open(image_filepath, "wb") as f:
			f.write(contents)

	# print(image_filepath)
	data, src_img = apply_transforms(image_filepath, cfg.data.test.pipeline)
	target_layers = get_default_traget_layers(model)
	reshape_transform = build_reshape_transform()
	
	cam = init_cam('GradCAM', model, target_layers, use_cuda,
				reshape_transform)
	
	grayscale_cam = cam(
        data['img'].unsqueeze(0),
        None,
        eigen_smooth=False,
        aug_smooth=False)
	grad_img_path = os.path.join(grad_path, 'grad_'+unique_filename)
	# print(grad_img_path)
	show_cam_grad(
        grayscale_cam, src_img, title='GradCAM', out_path=grad_img_path)
	print('start predict')
	result = inference_model(model, image_filepath)
	print('end predict')
	result['pred_label'] = int(result['pred_label'])
	"""
	show_image = Image.open(image_filepath).convert('RGB')
	buffer = BytesIO()
	show_image.save(buffer, format=file_ext[1:])
	img_base64 = base64.b64encode(buffer.getvalue()).decode()
	result.update({
		'image' : img_base64
	})
	"""
	print(result)
	return {"result": result, "grad_img_path" :grad_img_path}


if __name__ == "__main__":
	import uvicorn
	uvicorn.run(app, host="0.0.0.0", port=7777)
