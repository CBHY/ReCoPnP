import requests
import io
import streamlit as st
from streamlit_cropper import st_cropper
from PIL import Image, ImageEnhance
st.set_option('deprecation.showfileUploaderEncoding', False)

# Upload an image and set some options for demo purposes
st.header("Tuberculosis frontend Demo")
img_file = st.sidebar.file_uploader(label='Upload a file', type=['png', 'jpg'])
realtime_update = st.sidebar.checkbox(label="Update in Real Time", value=True)
# box_color = st.sidebar.color_picker(label="Box Color", value='#0000FF')
box_color ='#0000FF'
aspect_choice = st.sidebar.radio(label="Aspect Ratio", options=["1:1", "16:9", "4:3", "2:3", "Free"])
contrast_level = st.sidebar.slider('Contrast level', min_value=0.5, max_value=3.5, value=1.0)
brightness_level = st.sidebar.slider('Brightness level', min_value=0.5, max_value=3.5, value=1.0)
sharpness_level = st.sidebar.slider('Sharpness level', min_value=0.5, max_value=3.5, value=1.0)
aspect_dict = {
    "1:1": (1, 1),
    "16:9": (16, 9),
    "4:3": (4, 3),
    "2:3": (2, 3),
    "Free": None
}
aspect_ratio = aspect_dict[aspect_choice]

def pil_to_binary(image, enc_format = "png"):
	"""Convert PIL Image to base64-encoded image"""
	buffer = io.BytesIO()
	image.save(buffer, format=enc_format)
	buffer.seek(0)
	return buffer

if img_file:
	img = Image.open(img_file)
	contr_enhancer = ImageEnhance.Contrast(img)
	img = contr_enhancer.enhance(contrast_level)
	bright_enhancer = ImageEnhance.Brightness(img)
	img = bright_enhancer.enhance(brightness_level)
	sharp_enhancer = ImageEnhance.Sharpness(img)
	img = sharp_enhancer.enhance(sharpness_level)
	if not realtime_update:
		st.write("Double click to save crop")
	# Get a cropped image from the frontend
	cropped_img = st_cropper(img, realtime_update=realtime_update, box_color=box_color,
								aspect_ratio=aspect_ratio)
	thumnail_img = cropped_img.copy()
	# Manipulate cropped image at will
	st.write("Preview")
	_ = thumnail_img.thumbnail((150,150))
	st.image(thumnail_img)
	if st.button('submit'):
		# Convert the PIL image to base64 format
		buffer= pil_to_binary(cropped_img)

		# POST the image data as json to the FastAPI server
		url = "http://127.0.0.1:8000/predict"
		file = {"file": buffer}
		response = requests.post(url, files=file)

		# Print the response or do something else...
		grad_img = Image.open(response.json()['grad_img_path'])
		st.image(grad_img)
		st.code(response.text,'json')